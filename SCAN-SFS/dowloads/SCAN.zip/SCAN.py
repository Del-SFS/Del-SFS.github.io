
# =============================================================================
# SCAN - SFS COMPREHENSIVE ARCHIVE NETWORK (ONLINE VERSION)
# Developed by: Del 
# =============================================================================

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os, json, shutil, threading, zipfile, datetime, requests, io

# URL DEFINIDA PARA O SEU REPO.JSON RAW
REPO_URL = "https://raw.githubusercontent.com/Del-SFS/ModCenterSFS/refs/heads/main/repo.json"

APP_TITLE = "SCAN - SFS Comprehensive Archive Network"
CONFIG_FILE = "config.json"
ICON_FILE = "SCAN.ico"
LOG_FILE = "scan_log.txt"

class SCANApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1200x750")
        
        if os.path.exists(ICON_FILE):
            try: self.root.iconbitmap(ICON_FILE)
            except: pass

        self.root.configure(bg="#ffffff")
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        self.style.configure("Treeview", background="#ffffff", fieldbackground="#ffffff", 
                            foreground="#333333", rowheight=30, font=("Segoe UI", 9))
        self.style.map("Treeview", background=[('selected', '#0078d7')], foreground=[('selected', '#ffffff')])

        self.config = {"sfs_path": ""}
        self.repo_mods = {} # Dados do GitHub
        self.queue = set()   # Mods marcados [X]
        self.is_panel_open = False
        
        self.load_settings()
        self.setup_ui()
        
        # Inicia a busca dos mods no GitHub
        threading.Thread(target=self.fetch_github_data, daemon=True).start()

    def log_error(self, msg):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a") as f:
            f.write(f"[{timestamp}] SCAN_LOG: {msg}\n")

    def load_settings(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    self.config.update(json.load(f))
            except Exception as e: self.log_error(f"Config Load Error: {e}")

    def fetch_github_data(self):
        try:
            res = requests.get(REPO_URL, timeout=10)
            if res.status_code == 200:
                links = res.json()
                for link in links:
                    # Converte links do GitHub comuns para links RAW para conseguir ler o JSON
                    raw_link = link.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/")
                    m_res = requests.get(raw_link)
                    if m_res.status_code == 200:
                        m_data = m_res.json()
                        self.repo_mods[m_data["nome"]] = m_data
                
                self.root.after(0, self.refresh_list)
        except Exception as e:
            self.log_error(f"Github Sync Error: {e}")

    def setup_ui(self):
        # --- TOOLBAR ---
        self.toolbar = tk.Frame(self.root, bg="#f8f8f8", bd=1, relief="ridge")
        self.toolbar.pack(fill="x", side="top", ipady=12)

        self.btn_play = tk.Button(self.toolbar, text="🚀 PLAY SFS", bg="#0078d7", fg="white", 
                                 font=("Segoe UI", 10, "bold"), command=self.launch_sfs,
                                 relief="raised", bd=4, padx=22, cursor="hand2")
        self.btn_play.pack(side="left", padx=15)

        self.btn_apply = tk.Button(self.toolbar, text="APPLY CHANGES", bg="#2e7d32", fg="white",
                                   font=("Segoe UI", 9, "bold"), command=self.start_sync,
                                   relief="raised", bd=4, padx=15, cursor="hand2")
        self.btn_apply.pack(side="left", padx=5)

        self.btn_path = tk.Button(self.toolbar, text="Set Game Path", command=self.ask_path,
                                 bg="#ffffff", relief="groove", bd=2, font=("Segoe UI", 9))
        self.btn_path.pack(side="left", padx=20)

        tk.Label(self.toolbar, text="🔍", bg="#f8f8f8", font=("Segoe UI", 12)).pack(side="left", padx=(15, 0))
        self.search_entry = tk.Entry(self.toolbar, width=55, font=("Segoe UI", 11), bd=1, relief="solid")
        self.search_entry.insert(0, "Search your mods...")
        self.search_entry.pack(side="left", padx=8, ipady=5)
        self.search_entry.bind("<KeyRelease>", lambda e: self.refresh_list())

        # --- CORPO PRINCIPAL ---
        self.paned = tk.PanedWindow(self.root, orient="horizontal", bg="#dddddd", sashwidth=8)
        self.paned.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(self.paned, columns=("c","n","s"), show="headings", selectmode="browse")
        self.tree.heading("c", text="Inst.")
        self.tree.heading("n", text="Mod Name")
        self.tree.heading("s", text="Status")
        self.tree.column("c", width=90, anchor="center")
        self.tree.column("n", width=480)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_mod_select)
        self.tree.bind("<ButtonRelease-1>", self.on_click_check)
        self.paned.add(self.tree)

        # --- PAINEL DIREITO ---
        self.det_frame = tk.Frame(self.paned, bg="#ffffff")
        self.txt_info = tk.Text(self.det_frame, bg="#ffffff", font=("Segoe UI", 11), 
                                relief="flat", padx=30, pady=30, fg="#333333")
        self.txt_info.pack(fill="both", expand=True)
        self.txt_info.bind("<Key>", lambda e: "break")
        
        # Rodapé
        self.footer = tk.Frame(self.root, bg="#f2f2f2", height=50, bd=1, relief="sunken")
        self.footer.pack(fill="x", side="bottom")
        self.progress = ttk.Progressbar(self.footer, mode="determinate", length=650)
        self.progress.pack(side="left", padx=30, pady=15)

    def on_mod_select(self, event):
        selected = self.tree.selection()
        if not selected: return
        mod_name = self.tree.item(selected[0])["values"][1]
        self.render_psm(mod_name)

    def on_click_check(self, event):
        item_id = self.tree.identify_row(event.y)
        column = self.tree.identify_column(event.x)
        if not item_id: return
        
        mod_name = self.tree.item(item_id)["values"][1]
        if column == "#1": 
            if mod_name in self.queue: self.queue.remove(mod_name)
            else: self.queue.add(mod_name)
            self.refresh_list()

    def render_psm(self, name):
        if not self.is_panel_open:
            self.paned.add(self.det_frame, width=420)
            self.is_panel_open = True
        
        m = self.repo_mods.get(name, {})
        self.txt_info.config(state="normal")
        self.txt_info.delete(1.0, tk.END)
        
        content = f"🚀 DETALHES DO MOD\n{'='*30}\n"
        content += f"NOME: {name}\n"
        content += f"AUTOR: {m.get('autor', '---')}\n"
        content += f"VERSÃO: {m.get('versao', '1.0.0')}\n"
        content += f"TIPO: {m.get('tipo', '---')}\n"
        content += f"TAMANHO: {m.get('tamanho', '---')}\n\n"
        content += f"DESCRIÇÃO:\n{m.get('descricao', 'Sem descrição.')}\n"
        
        self.txt_info.insert(tk.END, content)
        self.txt_info.config(state="disabled")

    def refresh_list(self):
        self.tree.delete(*self.tree.get_children())
        query = self.search_entry.get().lower()
        if "search" in query: query = ""

        for name, data in self.repo_mods.items():
            if query and query not in name.lower(): continue
            mark = " [X] " if name in self.queue else " [   ] "
            status = "Online ☁️"
            self.tree.insert("", "end", values=(mark, name, status))

    def start_sync(self):
        if not self.config["sfs_path"]:
            return messagebox.showwarning("Setup", "Selecione a pasta do SFS!")
        
        final_list = list(self.queue)
        for mod_name in final_list:
            m = self.repo_mods[mod_name]
            for dep in m.get("dependencias", []):
                if dep not in final_list and dep in self.repo_mods:
                    final_list.append(dep)
            for conf in m.get("conflitos", []):
                if conf in final_list:
                    return messagebox.showerror("Conflito", f"O mod {mod_name} conflita com {conf}!")

        threading.Thread(target=self.run_sync_engine, args=(final_list,), daemon=True).start()

    def run_sync_engine(self, install_list):
        root_path = self.config["sfs_path"]
        self.progress["maximum"] = len(install_list)
        
        dest_map = {
            "mod": os.path.join(root_path, "Mods"),
            "parts": os.path.join(root_path, "Mods", "Custom Assets", "Parts"),
            "texture": os.path.join(root_path, "Mods", "Custom Assets", "Texture Packs"),
            "solar": os.path.join(root_path, "Spaceflight Simulator_Data", "Custom Solar Systems")
        }

        for i, name in enumerate(install_list):
            m = self.repo_mods[name]
            try:
                r = requests.get(m["download"])
                with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                    # Determina o destino baseado no tipo ou vai para a raiz se não reconhecido
                    target_base = dest_map.get(m.get('tipo', '').lower(), root_path)
                    target = os.path.join(target_base, name)
                    if not os.path.exists(target): os.makedirs(target)
                    z.extractall(target)
            except Exception as e: self.log_error(f"Erro no mod {name}: {e}")
            self.progress["value"] = i + 1

        messagebox.showinfo("SCAN", "Mods aplicados com sucesso!")

    def launch_sfs(self):
        exe = os.path.join(self.config.get("sfs_path", ""), "Spaceflight Simulator.exe")
        if os.path.exists(exe): os.startfile(exe)
        else: messagebox.showerror("Erro", "Jogo não encontrado.")

    def ask_path(self):
        p = filedialog.askdirectory()
        if p:
            self.config["sfs_path"] = p
            with open(CONFIG_FILE, "w") as f: json.dump(self.config, f)

if __name__ == "__main__":
    root = tk.Tk()
    app = SCANApp(root)
    root.mainloop()